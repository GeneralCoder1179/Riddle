def hint():
    print("I attack, I am from a different land.")

def guess():
    user_guess = input("Make a guess: ")
    if user_guess.lower() == "invader":
      print("You are correct. Good job.")
    else:
      print("You have got the wrong answer. Try again.")

def main():
    while(True):
     riddle="I come from a different land, I come to attack, I dislike you, I am armed, I do not speak much to you. What am I?"

print(" Welcome to the riddle game.")
print(riddle)

choice = input("Do not know much about riddles? Or what it is related to? Would you like to have hints? (H) or do you want to guess (G)?")

if choice.lower() == "h":
 hint()
elif choice.lower() == "g":
 guess()
else:
 print("Invalid choice.")

main()